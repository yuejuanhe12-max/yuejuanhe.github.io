# 佛经打卡排行榜网站部署指南

## 项目介绍
这是一个佛经打卡排行榜网站，支持多用户实时数据同步、用户自定义名称、累积佛号计数和响应式设计。

## 部署方法（小白友好）

### 方法一：使用 GitHub Pages（推荐）

1. **注册 GitHub 账号**
   - 访问 [GitHub官网](https://github.com)
   - 点击右上角 "Sign up" 创建免费账号

2. **创建新仓库**
   - 登录后，点击右上角 "+" 图标，选择 "New repository"
   - 仓库名称填写：`buddhist-scriptures`
   - 勾选 "Add a README file"
   - 点击 "Create repository"

3. **上传文件**
   - 进入新创建的仓库
   - 点击 "Add file" → "Upload files"
   - 拖拽上传 `index.html` 文件和 `firebase-config` 文件夹
   - 拉到底部点击 "Commit changes"

4. **开启 GitHub Pages**
   - 进入仓库的 "Settings" 页面
   - 点击左侧的 "Pages"
   - 在 "Branch" 下拉菜单选择 "main"，点击 "Save"
   - 稍等几分钟，刷新页面，会看到一个绿色提示和网站链接

5. **分享网站**
   - 复制 GitHub Pages 提供的链接（通常是 `https://你的用户名.github.io/buddhist-scriptures/`）
   - 分享给家人朋友即可

### 方法二：使用 Netlify（更简单）

1. **注册 Netlify 账号**
   - 访问 [Netlify官网](https://www.netlify.com)
   - 点击 "Sign up" 使用 GitHub 账号登录（更方便）

2. **部署网站**
   - 登录后，点击 "Add new site" → "Import an existing project"
   - 选择 "GitHub" 并授权
   - 选择你的 `buddhist-scriptures` 仓库
   - 点击 "Deploy site"
   - 等待部署完成，会自动生成一个随机域名

3. **自定义域名（可选）**
   - 在项目设置中可以设置自定义域名或修改为更友好的子域名

### 方法三：使用 Vercel

1. **注册 Vercel 账号**
   - 访问 [Vercel官网](https://vercel.com)
   - 点击 "Sign Up" 使用 GitHub 账号登录

2. **导入项目**
   - 登录后，点击 "New Project"
   - 选择你的 `buddhist-scriptures` 仓库
   - 点击 "Import"
   - 保持默认设置，点击 "Deploy"

3. **获取链接**
   - 部署完成后，会获得一个 `.vercel.app` 结尾的链接
   - 可以直接分享这个链接

## 重要说明

1. **Firebase 配置**
   - 当前项目已包含 Firebase 配置文件
   - 数据库已设置为公开读写权限，所有用户都可以访问

2. **数据安全**
   - 由于使用了公开的 Firebase 配置，建议仅在小范围内分享
   - 如需增强安全性，请联系开发者进行 Firebase 配置优化

3. **使用方法**
   - 首次访问需要设置用户名
   - 可以选择不同的佛经进行打卡
   - 支持查看今日排行和总排行
   - 所有数据会实时同步到所有设备

## 技术支持

如果遇到部署问题，可以：
1. 检查 Firebase 配置是否正确
2. 确保所有文件都已正确上传
3. 尝试清除浏览器缓存

祝修行精进，早证菩提！