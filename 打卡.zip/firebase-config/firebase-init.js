// Firebase配置
const firebaseConfig = {
    apiKey: "AIzaSyC5aT1K8yQ8zLz8X5Q2Z6W7V9B3N4M5K6J",
    authDomain: "buddhist-scriptures.firebaseapp.com",
    databaseURL: "https://buddhist-scriptures-default-rtdb.firebaseio.com",
    projectId: "buddhist-scriptures",
    storageBucket: "buddhist-scriptures.appspot.com",
    messagingSenderId: "123456789012",
    appId: "1:123456789012:web:abcdef1234567890abcdef"
};

// 初始化Firebase
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getDatabase, ref, get, set, onValue, update } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";

const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

// 导出数据库引用
export { database, ref, get, set, onValue, update };